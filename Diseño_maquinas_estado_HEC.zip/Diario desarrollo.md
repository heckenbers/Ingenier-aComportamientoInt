# **Diario de desarrollo**

## Diseño máquinas de estado

### Comportamiento de fantasmas

He empezado pensando en las distintas acciones, dividiendolas en acciones de ataque, defensivas, preventivas y “encerrado”. Estas son las acciones que pensé preliminarmente:

- **Ataque**: Perseguir, interceptar, bloquear power pill.  
- **Defensa**: Huir, refugiarse en compañero, dispersarse.  
- Encerrado

Después le pregunté a la IA Claude como afinar esas acciones preliminares:  
\------------------------------------------------------------------------------------------------------------------------------------  
**Prompt**  
Mis acciones actuales para una máquina de estados de los fantasmas son las siguientes, divididas en 3 categorías: Ataque: Perseguir (ir a la posicion de mspacman), Interceptar (intentar flanquear a mspacman si ya hay otro compañero persiguiendo), Bloquear power pill (Si se puede llegar a power pill antes que mspacman va hacia ella para bloquearla). Defensa: Huir (alejarse de mspacman, evitando ir todos por el mismo camino), refugiarse en compañero (si soy comestible y un compañero fantasma no, iré hacia él para que me proteja), dispersarse (si mspacman está lejos, ir a distintas esquinas para evitar ser comidos varios a la vez si se acerca). Encerrado (he sido comido y tengo que esperar a que vuelva mi turno). Dime como podriamos afinar estos comportamientos, cuales podríamos añadir?   
\------------------------------------------------------------------------------------------------------------------------------------  
**Respuesta**  
Tienes una buena base: ya cubre perseguir, cortar el paso, defender la power pill y coordinarse cuando hay comestibles. Te propongo afinar cuatro de tus acciones y añadir tres nuevas.

### **Cómo afinar las que tienes**

**Perseguir.** Ir a la posición de MsPacMan por el camino más corto, midiendo siempre la distancia con el último movimiento del fantasma, porque no puede darse la vuelta. Conviene que solo persiga **uno**: el más cercano a MsPacMan. Cuatro fantasmas persiguiendo por el camino más corto acaban en fila por el mismo pasillo, y en fila no cierran ningún bucle.

**Interceptar.** En lugar de ir a la posición de MsPacMan, ir a su **próximo cruce**, siguiendo el pasillo por el que va hasta el siguiente cruce. Perseguir es ir siempre por detrás; interceptar es esperarla donde va a llegar. Así el perseguidor la empuja y el interceptor le cierra la salida.

**Bloquear power pill.** La clave es la condición de “llegar antes”. Compara la distancia del fantasma **a la pill** con la de MsPacMan **a la misma pill**, con un margen generoso: llegar a la vez es lo peor que puede pasar, porque MsPacMan se la come con el fantasma al lado. Basta con que la bloquee uno, el que antes llegue.

**Huir → huida eficiente.** Dos mejoras:

* **Elegir bien la salida.** Huir con `getNextMoveAwayFromTarget` hace que casi todas las salidas empaten, y el empate se resuelve por el orden del `enum MOVE`, así que todos los fantasmas huyen por el mismo lado. Mejor descartar el pasillo por el que viene MsPacMan y elegir entre los demás, evitando los que usan otros comestibles.  
* **Huir antes, no después.** Si MsPacMan va a llegar a una power pill antes que el fantasma (justo el caso contrario a bloquear), lo mejor es empezar a huir **ya**, alejándose de la pill. Huir cuando ya eres comestible es tarde.

### **Qué añadir**

| Categoría | Acción | Qué hace |
| ----- | ----- | ----- |
| Defensa | **Volver al ataque** | Si el tiempo de comestible que le queda es menor que `2d/3` (siendo `d` la distancia a MsPacMan), deja de huir y vuelve a perseguir. Yendo hacia ella se acercan 3/2 nodos por tick, así que cuando se encuentren ya no será comestible. Gana posición mientras los demás siguen huyendo. |
| Estándar | **Vigilar power pill** | Situarse cerca de la power pill activa más cercana a MsPacMan **antes** de que ella vaya hacia allí. Es la versión preventiva de bloquear: el fantasma que vigila es el mejor candidato para bloquear cuando llegue el momento. |
| Estándar | **Patrullar píldoras** | Moverse hacia la zona del laberinto donde quedan más píldoras. MsPacMan tiene que ir allí tarde o temprano para terminar el nivel, así que el fantasma la espera donde va a tener que pasar, en lugar de vagar. |

Con estas, tu lista quedaría:

| Ataque | Defensa | Estándar |
| ----- | ----- | ----- |
| Perseguir | Huida eficiente | Vigilar power pill |
| Interceptar | Refugiarse en compañero | Patrullar píldoras |
| Bloquear power pill | Dispersarse | Encerrado |
|  | Volver al ataque |  |

### 

### **Para que funcionen juntas**

Lo más importante es que **los cuatro fantasmas no hagan lo mismo a la vez**. Una forma sencilla, sin necesidad de mensajes, es repartir los papeles cada tick según la distancia a MsPacMan: el más cercano persigue, el segundo intercepta, el tercero vigila la power pill y el cuarto patrulla. Como los cuatro ven el mismo estado, todos llegan al mismo reparto. Y como se recalcula cada tick, el papel de perseguidor es del que esté más cerca en cada momento, no siempre del mismo fantasma.

\------------------------------------------------------------------------------------------------------------------------  
Después diseñé la máquina de estados, con 4 superestados (normal, comestible, peligro por PP y encerrado), con sus transiciones. Para el superestado de “normal”, pedí ayuda a Claude para completar las transiciones, adjuntando el estado sin transiciones:  
\------------------------------------------------------------------------------------------------------------------------------------  
**Prompt**  
Esta es mi máquina de estados, ahora hagamos superestado de "normal" por dentro, debe de empezar en perseguir, y pasar a interceptar si ya hay algun compañero persiguiendo, cual podría ser la condicion de entrada vigilar (quiero que vaya a la power pill mas cercana a mspacman para que sea posible bloquear la pildora de poder si es necesario)? Y de patrullar pildoras? Quiero que los fantasmas sean agresivos y no estén esperando a que pacman vaya a por sus pildoras.  
\------------------------------------------------------------------------------------------------------------------------------------  
**Respuesta**  
La idea es repartir los cuatro papeles **por prioridad**: perseguir, interceptar, vigilar y patrullar. Cada fantasma ocupa el papel más importante que quede libre, y si uno superior se queda vacío (porque su fantasma se vuelve comestible o pasa a PELIGRO), sube el mejor candidato.  
**Transiciones dentro de NORMAL**  
Estado inicial: **PERSEGUIR**.

### 

| Desde | Hacia | Condición |
| ----- | ----- | ----- |
| PERSEGUIR | INTERCEPTAR | Ya hay un compañero persiguiendo (\*) |
| INTERCEPTAR | VIGILAR | Quedan power pills, nadie vigila y es el más cercano a la pill objetivo (\*\*) |
| INTERCEPTAR | PATRULLAR | Ya hay un compañero interceptando y otro vigilando (\*\*\*) |
| Cualquiera | PERSEGUIR | Nadie persigue y es el más cercano a Ms. Pacman |
| VIGILAR, PATRULLAR | INTERCEPTAR | Nadie intercepta y es el más cercano a Ms. Pacman |
| VIGILAR | INTERCEPTAR | No quedan power pills |
| PATRULLAR | VIGILAR | Nadie vigila, quedan power pills y es el más cercano a la pill objetivo |

### (\*) Si dos están persiguiendo a la vez, sigue el más cercano a Ms. Pacman y el otro pasa a interceptar. Si empatan, se desempata por el orden del enum `GHOST`.

### (\*\*) La pill objetivo es la power pill activa más cercana a Ms. Pacman. Vigila el fantasma (no perseguidor) más cercano a ella, porque será el que antes llegue si hay que bloquearla. Cuando Ms. Pacman se acerque a la pill, pasará a PELIGRO POR PÍLDORA y será el candidato natural a BLOQUEAR.

### (\*\*\*) Para que sea agresivo, el objetivo de patrullar es **la zona de píldoras más cercana a Ms. Pacman**, no la zona con más píldoras. Así el fantasma se coloca por delante de ella, donde va a comer, en lugar de esperar en otra parte del mapa.

### **Por qué es agresivo**

* ### Los **cuatro papeles se mueven alrededor de Ms. Pacman**: perseguir va a ella, interceptar a su próximo cruce, vigilar a la pill más cercana a ella y patrullar a la comida que tiene más cerca.

* ### Ningún fantasma se queda esperando en una zona lejana.

* ### Si el perseguidor desaparece, el más cercano ocupa su puesto enseguida, así que siempre hay alguien encima de ella.

\------------------------------------------------------------------------------------------------------------------------------------  
Después terminé de completar el diagrama.

### Comportamiento de Ms Pacman

El comportamiento de MsPacman es tal cual siempre ha sido, evitar los fantasmas mientras está movilizándose por los pasillos comiendo píldoras para acumular puntos y luego poder comer la píldora de súper poder que otorga una franja de tiempo corto para poder comer los fantasmas y ser inmune a ser cazados por ellos.

**Acciones**

Estas son las capacidades físicas y decisiones de movimiento que Pac-Man puede ejecutar en el mapa. Cada una representa una estrategia de navegación activa:

* **Comer píldora:** Ir hacia la píldora común activa más cercana del mapa utilizando la ruta más corta posible.  
* **Ir a la píldora de poder:** Dirigirse hacia la píldora de poder (PowerPill) activa más cercana calculando la ruta euclidiana óptima.  
* **Huir:** Desplazarse en dirección opuesta al fantasma no comestible más cercano para maximizar la distancia de escape.  
* **Comer fantasma:** Perseguir al fantasma comestible (isGhostEdible) más cercano utilizando la ruta de aproximación más rápida.  
* **Evitar camino:** Cambiar la trayectoria actual hacia un nodo alternativo cuando el camino directo hacia una píldora está interceptado por un fantasma.

**Las Transiciones** 

Convertimos las transiciones en variables lógicas y distancias numéricas exactas basadas en nodos (medidas por distancia Euclídea Constants.DM.EUCLID).

Para evitar que Pac-Man se quede "titubeando" (entrando y saliendo de un estado repetidamente en un mismo pasillo), aplicamos **histéresis** con un margen de seguridad de **5 nodos**:

De "Comer píldora" a "Huir" (Y viceversa)

* **Condición de Ida (Entrada a Huir):** nearestGhost \!= null **Y** \!game.isGhostEdible(nearestGhost) **Y** la distancia al fantasma es **menor a 25 nodos**.  
* **Condición de Vuelta (Salir de Huir):** La distancia al fantasma peligroso vuelve a ser **mayor o igual a 30 nodos** (Margen de 5 nodos para estabilizar el comportamiento), o el fantasma pasa a ser comestible.

De "Comer píldora" a "Comer fantasma" (Y viceversa)

* **Condición de Ida (Entrada a Cazar):** nearestGhost \!= null **Y** game.isGhostEdible(nearestGhost) **Y** la distancia al fantasma comestible es **menor a 40 nodos**.  
* **Condición de Vuelta (Salir de Cazar):** El tiempo de vulnerabilidad del fantasma termina (\!isGhostEdible), el fantasma es devorado, o la distancia al fantasma supera los **45 nodos**.

De "Comer píldora" a "Ir a la píldora" (Y viceversa)

* **Condición de Ida (Peligro preventivo):** nearestGhost \!= null **Y** la distancia entre Pac-Man y la píldora de poder más cercana es **menor o igual al parámetro limit** (por ejemplo, 15 nodos), anticipando que necesitará el poder pronto.  
* **Condición de Vuelta (Volver al bucle normal):** La píldora de poder es consumida, o la distancia a la píldora de poder vuelve a ser **mayor a limit \+ 5 nodos** si Pac-Man decide cambiar de rumbo.

De "Ir a la píldora" a "Evitar camino"

* **Condición de Ida (Ruta interceptada):** El camino hacia la píldora de poder contiene un fantasma no comestible a una distancia **menor a 12 nodos** del objetivo.  
* **Condición de Vuelta (Ruta liberada):** El fantasma se aleja del camino de la píldora a una distancia **mayor a 17 nodos**.

**Estados:**

* **Huir:** Estado por default, donde aparte de buscar las píldoras para sumar puntos y las píldoras de poder, al momento de que comience en su estado inicial está buscando las píldoras y huyendo de los fantasmas, huyendo por el pasillo donde esté lo más lejos de los fantasmas, luego de haber comido una píldora de poder y que termine el tiempo de efecto de esta, vuelve al estado de huir.  
* **Ir a la píldora:** Estamos en este estado cuando huimos de los fantasmas y estamos obteniendo puntos, el objetivo siempre será obtener la pildora de poder para que MsPacman pueda comerse los fantasmas y obtener más puntos  
* **Comer Pildora:** Transisionamos a este estado cuando ingerimos la pildora, estado donde aumentamos nuestra velocidad para poder comer los fantasmas en una franja de tiempo, luego del efecto volvemos al estado huir, evitando contacto con los fantasmas.  
* **Evitar camino:** Un estado implicito del fantasma donde siempre que está corriendo la cuadrilla, analiza que camino es mejor para tomar el que menos fantasma tenga o el camino que menos nos dirija a uno donde haya fantasmas.

| Estado actual | Transición | Método |
| ----- | ----- | ----- |
| Default | nearestGhost \== null | TowardsTarget(ActivePills) |
| Comer píldora | nearestGhost \!= null && \!isGhostEdible | AwayFromTarget(Ghost) |
| Comer píldora | nearestGhost \!= null && isGhostEdible | TowardsTarget(Ghost) |
| Ir a la pildora | Fantasma bloquea ruta |  |

### 

